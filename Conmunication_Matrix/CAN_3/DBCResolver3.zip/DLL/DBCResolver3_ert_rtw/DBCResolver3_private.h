/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: DBCResolver3_private.h
 *
 * Code generated for Simulink model 'DBCResolver3'.
 *
 * Model version                  : 2.208
 * Simulink Coder version         : 9.8 (R2022b) 13-May-2022
 * C/C++ source code generated on : Tue Dec  6 14:17:35 2022
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_DBCResolver3_private_h_
#define RTW_HEADER_DBCResolver3_private_h_
#include "rtwtypes.h"
#include "DBCResolver3_types.h"
#endif                                 /* RTW_HEADER_DBCResolver3_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
